/*import Home from '@/components/Home'
import Login from '@/components/Login'
import Register from '@/components/Register'
import logreg from '@/components/LoginRegister'
import Dashboard from '@/components/Dashboard' */
const rouutes = [
   /*{
      path: '*',
      redirect: '/login/app2'
   },{
      path: '/app2',
      name: 'Home2',
      component: Home
   },{
      path: '/login/app2/:uid',
      name: 'login2',
      component: Login
   },{
      path: '/register/app2',
      name: 'register2',
      component: Register
   },{
      path: '/logreg/app2',
      name: 'logreg2',
      component: logreg
   },{
      path: '/dashboard/app2',
      name: 'Dashboard2',
      component: Dashboard,
      meta: {
         requiresAuth: true
      }
   }*/
];
export default rouutes;